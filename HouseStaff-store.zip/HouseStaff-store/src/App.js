import React from "react";
import Header from "./components/Header";
import Footer from "./components/Footer";
import Items from "./components/Items";
import Categories from "./components/Categories";
import ShowFullItem from "./components/ShowFullItem";
import { Fa0 } from "react-icons/fa6";

class App extends React.Component {
  constructor(props) {
    super(props)
    this.state = {
      orders: [],
      currentItems: [],
        items: [
        {
          id: 1,
          title: "Диван",
          img: "1.jpeg",
          desc: "Мягкий ортопедический диван .",
          category: "sofa",
          price: "549.99",
        },
        {
          id: 2,
          title: "Кресло",
          img: "2.jpeg",
          desc: "Удобное кресло с мягкой обивкой для отдыха.",
          category: "chair",
          price: "299.99",
        },
        {
          id: 3,
          title: "Стол обеденный",
          img: "3.jpeg",
          desc: "Просторный стол из натурального дуба.",
          category: "table",
          price: "799.99",
        },
        {
          id: 4,
          title: "Кровать двуспальная",
          img: "4.jpeg",
          desc: "Стильная кровать с ортопедическим матрасом.",
          category: "bed",
          price: "1299.99",
        },
        {
          id: 5,
          title: "Шкаф-купе",
          img: "5.jpeg",
          desc: "Вместительный шкаф с зеркальными дверцами.",
          category: "storage",
          price: "899.99",
        }
      ],
      ShowFullItem: false,
      fullItem: {}
    };
    this.state.currentItems = this.state.items
    this.addToOrder = this.addToOrder.bind(this)
    this.deleteOrder = this.deleteOrder.bind(this)
    this.chooseCategory = this.chooseCategory.bind(this)
    this.onShowItem = this.onShowItem.bind(this)

  }

  render() {
    return (
      <div className="wrapper">
        <Header orders={this.state.orders} onDelete={this.deleteOrder}/>
        <Categories chooseCategory={this.chooseCategory}/>
        <Items onShowItem={this.onShowItem} items={this.state.currentItems} onAdd={this.addToOrder} />

        {this.state.ShowFullItem && <ShowFullItem onAdd={this.addToOrder} onShowItem={this.onShowItem} item={this.state.fullItem} />}
        <Footer />
      </div>
    );
  }
  onShowItem(item){
    this.setState({fullItem: item})
    this.setState({ShowFullItem: !this.state.ShowFullItem})
  }

  chooseCategory(category){
    if(category === "all"){
      this.setState({ currentItems: this.state.items})
      return
    }

    this.setState({
      currentItems: this.state.items.filter(el => el.category === category)
    })
    
  }

  deleteOrder(id){
    this.setState({orders: this.state.orders.filter(el => el.id !== id )})
    
  }

  addToOrder(item){
    let isInArray = false
    this.state.orders.forEach(el => {
      if(el.id === item.id)
        isInArray = true
    })
    if(!isInArray)
    this.setState({orders: [...this.state.orders, item ]})
    
    
  }
}

export default App;
